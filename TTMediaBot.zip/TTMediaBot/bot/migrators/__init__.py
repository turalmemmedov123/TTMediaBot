from bot.migrators import cache_migrator, config_migrator
