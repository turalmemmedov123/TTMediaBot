class ApiHttpError(Exception):
    pass


class ApiError(Exception):
    pass
